import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-object',
  templateUrl: './course-object.component.html',
  styleUrls: ['./course-object.component.scss']
})
export class CourseObjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
